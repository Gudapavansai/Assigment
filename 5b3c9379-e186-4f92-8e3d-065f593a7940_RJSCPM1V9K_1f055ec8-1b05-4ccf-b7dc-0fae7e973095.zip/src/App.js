import React from 'react'
import EditableText from './components/EditableText'

function App() {
  return <EditableText />
}

export default App
