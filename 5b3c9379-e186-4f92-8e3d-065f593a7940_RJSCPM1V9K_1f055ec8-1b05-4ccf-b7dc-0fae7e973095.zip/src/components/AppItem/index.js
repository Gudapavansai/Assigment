import React, { useState } from "react";

const EditableTextInput = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [text, setText] = useState("Click to edit this text");

  const handleTextChange = (event) => {
    setText(event.target.value);
  };

  const toggleEditing = () => {
    setIsEditing(!isEditing);
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif", margin: "20px" }}>
      {isEditing ? (
        <input
          type="text"
          value={text}
          onChange={handleTextChange}
          onBlur={toggleEditing}
          autoFocus
          style={{
            padding: "5px",
            fontSize: "16px",
            width: "300px",
          }}
        />
      ) : (
        <span
          onClick={toggleEditing}
          style={{
            padding: "5px",
            fontSize: "16px",
            cursor: "pointer",
            borderBottom: "1px dashed gray",
          }}
        >
          {text}
        </span>
      )}
    </div>
  );
};

export default EditableTextInput;
